package blezerbot.buildings;

import battlecode.common.*;
import java.util.*;
import blezerbot.*;

public class Refinery extends Building {


    public Refinery(RobotController rc) throws GameActionException {
        super(rc);
    }

    public void run() throws GameActionException {
        super.run();
    }

}